user_num=int(input())
x=int(input())
user_num2=int((user_num/x))
user_num3=int((user_num2/x))
user_num4=int((user_num3/x))
print(user_num2, user_num3, user_num4)

